__author__ = "Inada Naoki <songofacandy@gmail.com>"
version_info = (2, 2, 0, "rc", 1)
__version__ = "2.2.0.rc1"
